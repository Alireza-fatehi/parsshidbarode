package com.parsshid.barcode

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("parsshid_inventory", MODE_PRIVATE) }
    private val rows = mutableListOf<Pair<String, String>>()
    private lateinit var codeInput: EditText
    private lateinit var searchInput: EditText
    private lateinit var countText: TextView
    private lateinit var statusText: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var scannerBox: FrameLayout
    private lateinit var previewView: PreviewView
    private var scanning = false
    private var lastScanned = ""
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startScanner() else toast("برای اسکن بارکد، اجازه دوربین لازم است")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11,39,69)
        window.navigationBarColor = android.graphics.Color.rgb(11,39,69)
        loadRows()
        buildUi()
        renderRows()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFFF3F6FA.toInt()) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(24)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(20)); background = rounded(0xFF123C69.toInt(), 20) }
        header.addView(text("پارس‌شید", 27, 0xFFFFFFFF.toInt(), true))
        header.addView(text("سامانه ثبت و کنترل بارکد انبار", 14, 0xFFDCE8F5.toInt(), false).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(header, lp(match, wrap, 0, 0, 0, 14))

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val statCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(0xFFFFFFFF.toInt(), 16) }
        statCard.addView(text("کل کارتن‌های ثبت‌شده", 13, 0xFF607080.toInt(), false))
        countText = text("0", 29, 0xFF123C69.toInt(), true)
        statCard.addView(countText)
        stats.addView(statCard, LinearLayout.LayoutParams(0, wrap, 1f))
        root.addView(stats, lp(match, wrap, 0, 0, 0, 14))

        val entryCard = card()
        entryCard.addView(text("ثبت محصول", 18, 0xFF172B4D.toInt(), true))
        codeInput = EditText(this).apply { hint = "شماره بارکد روی کارتن"; textSize = 16f; singleLine = true; setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(0xFFF4F7FA.toInt(), 12); layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT }
        entryCard.addView(codeInput, lp(match, wrap, 0, 12, 0, 8))
        val addBtn = button("＋  ثبت بارکد", 0xFF123C69.toInt()) { addCode(codeInput.text.toString()) }
        entryCard.addView(addBtn, lp(match, dp(52), 0, 0, 0, 8))
        entryCard.addView(button("▣  اسکن با دوربین", 0xFF168B78.toInt()) { requestScanner() }, lp(match, dp(50)))
        statusText = text("بارکد هر کارتن فقط یک‌بار ثبت می‌شود.", 12, 0xFF607080.toInt(), false)
        entryCard.addView(statusText.apply { setPadding(0, dp(10), 0, 0) })
        root.addView(entryCard, lp(match, wrap, 0, 0, 0, 14))

        val listCard = card()
        listCard.addView(text("فهرست بارکدها", 18, 0xFF172B4D.toInt(), true))
        searchInput = EditText(this).apply { hint = "جستجو در بارکدها"; textSize = 14f; singleLine = true; setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(0xFFF4F7FA.toInt(), 12); layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT }
        searchInput.addTextChangedListener(SimpleWatcher { renderRows() })
        listCard.addView(searchInput, lp(match, wrap, 0, 10, 0, 8))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listCard.addView(listBox)
        listCard.addView(button("خروجی CSV برای اکسل", 0xFF123C69.toInt()) { exportCsv() }, lp(match, dp(48), 0, 12, 0, 8))
        listCard.addView(button("پاک کردن همه اطلاعات", 0xFFB42332.toInt()) { confirmClear() }, lp(match, dp(46)))
        root.addView(listCard, lp(match, wrap))

        scannerBox = FrameLayout(this).apply { visibility = View.GONE; background = rounded(0xFF101820.toInt(), 16) }
        previewView = PreviewView(this)
        scannerBox.addView(previewView, FrameLayout.LayoutParams(match, dp(270)))
        val close = button("بستن دوربین", 0xFFB42332.toInt()) { stopScanner() }
        val closeParams = FrameLayout.LayoutParams(match, dp(48), Gravity.BOTTOM)
        scannerBox.addView(close, closeParams)
        root.addView(scannerBox, lp(match, dp(320), 0, 0, 0, 12))
    }

    private fun addCode(raw: String) {
        val code = raw.trim()
        if (code.isBlank()) { statusText.text = "شماره بارکد را وارد کن."; return }
        if (rows.any { it.first.equals(code, true) }) { statusText.text = "⚠ این بارکد قبلاً ثبت شده است: $code"; statusText.setTextColor(0xFFB42332.toInt()); return }
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        rows.add(0, code to date)
        saveRows(); codeInput.setText(""); statusText.text = "✓ بارکد با موفقیت ثبت شد."; statusText.setTextColor(0xFF168B78.toInt()); renderRows()
    }

    private fun renderRows() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val query = if (::searchInput.isInitialized) searchInput.text.toString().trim() else ""
        val filtered = rows.filter { it.first.contains(query, true) }
        if (::countText.isInitialized) countText.text = rows.size.toString()
        if (filtered.isEmpty()) {
            listBox.addView(text(if (rows.isEmpty()) "هنوز بارکدی ثبت نشده است." else "موردی پیدا نشد.", 14, 0xFF607080.toInt(), false).apply { setPadding(dp(4), dp(18), dp(4), dp(18)) })
        }
        filtered.forEachIndexed { index, item ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(if (index % 2 == 0) 0xFFF5F8FC.toInt() else 0xFFFFFFFF.toInt(), 10) }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.LEFT }
            details.addView(text(item.first, 16, 0xFF172B4D.toInt(), true))
            details.addView(text(item.second, 11, 0xFF607080.toInt(), false).apply { setPadding(0, dp(4), 0, 0) })
            line.addView(details, LinearLayout.LayoutParams(0, wrap, 1f))
            line.addView(button("حذف", 0xFFB42332.toInt()) { rows.remove(item); saveRows(); renderRows() }.apply { textSize = 12f; setPadding(dp(10), 0, dp(10), 0) }, lp(wrap, dp(38)))
            listBox.addView(line, lp(match, wrap, 0, 0, 0, 6))
        }
    }

    private fun requestScanner() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startScanner() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startScanner() {
        if (scanning) return
        scanning = true; lastScanned = ""; scannerBox.visibility = View.VISIBLE
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val scanner = BarcodeScanning.getClient()
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    val media = imageProxy.image
                    if (media == null) { imageProxy.close(); return@setAnalyzer }
                    val input = InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees)
                    scanner.process(input).addOnSuccessListener { found ->
                        val value = found.firstOrNull()?.rawValue
                        if (!value.isNullOrBlank() && value != lastScanned) {
                            lastScanned = value
                            runOnUiThread { addCode(value); stopScanner() }
                        }
                    }.addOnCompleteListener { imageProxy.close() }
                }
                provider.unbindAll(); provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) { scanning = false; scannerBox.visibility = View.GONE; toast("دوربین راه‌اندازی نشد") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopScanner() {
        scanning = false; scannerBox.visibility = View.GONE
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) {}
    }

    private fun exportCsv() {
        if (rows.isEmpty()) { toast("هنوز بارکدی برای خروجی وجود ندارد"); return }
        val csv = "Barcode,Date\r\n" + rows.joinToString("\r\n") { "\"${it.first.replace("\"", "\"\"")}\",\"${it.second}\"" }
        try {
            val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "Parsshid_Barcodes.csv"); put(MediaStore.Downloads.MIME_TYPE, "text/csv") }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri == null) { toast("ساخت فایل ممکن نشد"); return }
            contentResolver.openOutputStream(uri)?.use { it.write(("\uFEFF" + csv).toByteArray(Charsets.UTF_8)) }
            toast("فایل در پوشه Downloads ذخیره شد")
        } catch (e: Exception) { toast("خروجی گرفتن ناموفق بود") }
    }

    private fun confirmClear() {
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("حذف همه بارکدها؟").setMessage("این کار قابل برگشت نیست.")
            .setNegativeButton("انصراف", null).setPositiveButton("حذف همه") { _, _ -> rows.clear(); saveRows(); renderRows(); toast("فهرست پاک شد") }.show()
    }

    private fun loadRows() {
        try { val a = JSONArray(prefs.getString("rows", "[]")); for (i in 0 until a.length()) { val o = a.getJSONObject(i); rows.add(o.getString("code") to o.getString("date")) } } catch (_: Exception) {}
    }
    private fun saveRows() { val a = JSONArray(); rows.forEach { a.put(JSONObject().put("code", it.first).put("date", it.second)) }; prefs.edit().putString("rows", a.toString()).apply() }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(0xFFFFFFFF.toInt(), 18) }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD) }
    private fun button(s: String, color: Int, action: () -> Unit) = com.google.android.material.button.MaterialButton(this).apply { text = s; textSize = 15f; isAllCaps = false; setTextColor(-1); backgroundTintList = android.content.res.ColorStateList.valueOf(color); cornerRadius = dp(12); setOnClickListener { action() } }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun lp(w: Int, h: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { setMargins(left, top, right, bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
    companion object { const val match = ViewGroup.LayoutParams.MATCH_PARENT; const val wrap = ViewGroup.LayoutParams.WRAP_CONTENT }
}

private class SimpleWatcher(val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
