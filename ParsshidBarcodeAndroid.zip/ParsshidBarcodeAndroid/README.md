# Parsshid Barcode Android App

A Persian RTL Android inventory app for carton barcode registration. Features: offline local storage, duplicate detection, camera barcode scanning with ML Kit, search, delete, item count, and CSV export to Downloads.

## Build APK on GitHub Actions
1. Upload the contents of this folder into a GitHub repository (keep folder structure).
2. Open the repository's Actions tab and run `Build Parsshid APK` (or push to `main`).
3. Open the completed workflow run and download the `ParsshidBarcode-APK` artifact.

The app stores data locally on the device. Export CSV backups regularly.
